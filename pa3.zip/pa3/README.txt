Run test_chess.py to test out the algorithms. You can change which players/AI you use there.
You can also call one of my functions on the board to start with a simplified board.

I also have the AI printing statistics for each state, for comparing. You can comment them out in any given
best_move method.
